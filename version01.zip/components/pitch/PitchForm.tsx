'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ArrowRight, Film, Tv, Sparkles } from 'lucide-react';

const FormSchema = z.object({
  pitch: z.string().min(20, 'Au moins 20 caractères, on a besoin d’un peu de matière.'),
  format: z.enum(['fiction', 'documentaire', 'pub']),
  stage: z.enum(['idee', 'scenario', 'financement', 'tournage']),
  budget: z.enum(['<500k', '500k-2M', '2M-10M', '+10M']),
  name: z.string().min(2, 'Votre nom, s’il vous plaît.'),
  email: z.string().email('Email invalide.'),
  phone: z.string().min(6, 'Numéro trop court.'),
  company: z.string().optional(),
});

type FormData = z.infer<typeof FormSchema>;

const STEPS = ['pitch', 'format', 'stage', 'budget', 'identity', 'send'] as const;

export function PitchForm() {
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    register,
    control,
    handleSubmit,
    trigger,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(FormSchema),
    mode: 'onTouched',
  });

  const next = async () => {
    const fields: (keyof FormData)[][] = [
      ['pitch'],
      ['format'],
      ['stage'],
      ['budget'],
      ['name', 'email', 'phone'],
    ];
    if (step < STEPS.length - 1) {
      const ok = await trigger(fields[step]);
      if (ok) setStep((s) => s + 1);
    }
  };

  const onSubmit = async (data: FormData) => {
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch('/api/pitch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error('Échec de l’envoi.');
      setDone(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur inconnue');
    } finally {
      setSubmitting(false);
    }
  };

  if (done) return <ClapEnd />;

  return (
    <div className="min-h-screen bg-noir-salle texture-grain flex flex-col">
      {/* Pellicule progress */}
      <div className="fixed top-0 left-0 right-0 z-40 h-3 bg-noir-salle/90 flex">
        {STEPS.map((_, i) => (
          <div
            key={i}
            className={`flex-1 border-r border-noir-salle ${
              i <= step ? 'bg-or-akham' : 'bg-anthracite-2'
            }`}
            style={{
              backgroundImage:
                i <= step
                  ? 'radial-gradient(circle, rgba(8,8,8,0.7) 30%, transparent 31%)'
                  : 'none',
              backgroundSize: '12px 100%',
            }}
          />
        ))}
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="flex-1 flex items-center pt-32 pb-20">
        <div className="w-full max-w-3xl mx-auto px-6 md:px-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.2 } }}
              exit={{ opacity: 0, y: -10, transition: { duration: 0.2 } }}
            >
              <span className="meta">Étape {step + 1} / {STEPS.length}</span>

              {step === 0 && (
                <Carton title="Votre histoire en une phrase ?">
                  <textarea
                    {...register('pitch')}
                    placeholder="Il était une fois…"
                    rows={4}
                    className="mt-8 w-full bg-transparent border-b-2 border-or-akham/50 focus:border-or-akham outline-none text-ivoire font-display text-3xl md:text-5xl leading-snug py-4 placeholder:text-ivoire-ghost"
                  />
                  <FieldError msg={errors.pitch?.message} />
                </Carton>
              )}

              {step === 1 && (
                <Carton title="Quel format ?">
                  <Controller
                    name="format"
                    control={control}
                    render={({ field }) => (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-10">
                        {[
                          { v: 'fiction', label: 'Fiction', icon: <Film size={32} /> },
                          { v: 'documentaire', label: 'Documentaire', icon: <Tv size={32} /> },
                          { v: 'pub', label: 'Publicité / Marque', icon: <Sparkles size={32} /> },
                        ].map((o) => (
                          <button
                            type="button"
                            key={o.v}
                            onClick={() => field.onChange(o.v)}
                            className={`p-8 border-2 transition-all text-left ${
                              field.value === o.v
                                ? 'border-or-akham bg-or-akham/10 text-or-akham'
                                : 'border-ivoire-ghost text-ivoire hover:border-or-akham'
                            }`}
                          >
                            <span className="block">{o.icon}</span>
                            <span className="font-display text-3xl block mt-4">{o.label}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  />
                  <FieldError msg={errors.format?.message} />
                </Carton>
              )}

              {step === 2 && (
                <Carton title="Où en êtes-vous ?">
                  <Controller
                    name="stage"
                    control={control}
                    render={({ field }) => (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-10">
                        {[
                          { v: 'idee', label: 'Idée' },
                          { v: 'scenario', label: 'Scénario' },
                          { v: 'financement', label: 'Financement' },
                          { v: 'tournage', label: 'Prêt à tourner' },
                        ].map((o) => (
                          <button
                            type="button"
                            key={o.v}
                            onClick={() => field.onChange(o.v)}
                            className={`p-6 border-2 font-display text-2xl transition-all ${
                              field.value === o.v
                                ? 'border-or-akham bg-or-akham/10 text-or-akham'
                                : 'border-ivoire-ghost text-ivoire hover:border-or-akham'
                            }`}
                          >
                            {o.label}
                          </button>
                        ))}
                      </div>
                    )}
                  />
                  <FieldError msg={errors.stage?.message} />
                </Carton>
              )}

              {step === 3 && (
                <Carton title="Votre horizon budgétaire ?">
                  <Controller
                    name="budget"
                    control={control}
                    render={({ field }) => (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-10">
                        {[
                          { v: '<500k', label: '< 500K DA' },
                          { v: '500k-2M', label: '500K – 2M DA' },
                          { v: '2M-10M', label: '2M – 10M DA' },
                          { v: '+10M', label: '+ 10M DA' },
                        ].map((o) => (
                          <button
                            type="button"
                            key={o.v}
                            onClick={() => field.onChange(o.v)}
                            className={`p-5 border-2 font-display text-2xl transition-all ${
                              field.value === o.v
                                ? 'border-or-akham bg-or-akham/10 text-or-akham'
                                : 'border-ivoire-ghost text-ivoire hover:border-or-akham'
                            }`}
                          >
                            {o.label}
                          </button>
                        ))}
                      </div>
                    )}
                  />
                  <FieldError msg={errors.budget?.message} />
                </Carton>
              )}

              {step === 4 && (
                <Carton title="Qui êtes-vous ?">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
                    <Field label="Nom" {...register('name')} error={errors.name?.message} />
                    <Field label="Email" type="email" {...register('email')} error={errors.email?.message} />
                    <Field label="Téléphone" type="tel" {...register('phone')} error={errors.phone?.message} />
                    <Field label="Société (optionnel)" {...register('company')} />
                  </div>
                </Carton>
              )}

              {step === 5 && (
                <Carton title="Tout est prêt — moteur ?">
                  <p className="mt-8 text-ivoire-muted text-lg max-w-xl">
                    Cliquez sur « Envoyer » pour transmettre votre pitch à l’équipe Akham.
                    Nous vous répondons sous 48h ouvrées.
                  </p>
                  {error && <p className="mt-4 text-live-red text-sm">{error}</p>}
                </Carton>
              )}
            </motion.div>
          </AnimatePresence>

          <div className="flex justify-between mt-16">
            <button
              type="button"
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0 || submitting}
              className="meta text-ivoire-muted hover:text-or-akham disabled:opacity-30 disabled:cursor-not-allowed"
            >
              ← Précédent
            </button>

            {step < STEPS.length - 1 ? (
              <button type="button" onClick={next} className="btn-or" disabled={submitting}>
                Continuer <ArrowRight size={16} />
              </button>
            ) : (
              <button type="submit" className="btn-or" disabled={submitting}>
                {submitting ? 'Envoi…' : 'Envoyer le pitch'}{' '}
                <ArrowRight size={16} />
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}

function Carton({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2
        className="h-display text-or-akham mt-6"
        style={{ fontSize: 'clamp(36px, 5.5vw, 80px)', lineHeight: 1.05 }}
      >
        {title}
      </h2>
      {children}
    </div>
  );
}

const Field = ({
  label,
  error,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string } & {
  name?: string;
}) => (
  <label className="block">
    <span className="meta text-ivoire-muted">{label}</span>
    <input
      {...props}
      className="mt-2 block w-full bg-transparent border-b border-ivoire-ghost focus:border-or-akham outline-none text-ivoire text-xl py-3"
    />
    <FieldError msg={error} />
  </label>
);

const FieldError = ({ msg }: { msg?: string }) =>
  msg ? <p className="mt-2 text-live-red text-xs meta">{msg}</p> : null;

function ClapEnd() {
  return (
    <div className="min-h-screen bg-noir-salle flex items-center justify-center text-center px-6">
      <div>
        <motion.div
          initial={{ rotate: -25, y: -100, opacity: 0 }}
          animate={{ rotate: 0, y: 0, opacity: 1 }}
          transition={{ duration: 0.6, ease: 'backOut' }}
          className="mx-auto w-40 h-28 relative"
          aria-hidden
        >
          <div className="absolute inset-x-0 bottom-0 h-20 bg-noir-salle border-2 border-or-akham" />
          <motion.div
            initial={{ rotate: -35 }}
            animate={{ rotate: 0 }}
            transition={{ delay: 0.5, duration: 0.4 }}
            style={{ transformOrigin: 'left center' }}
            className="absolute top-0 left-0 right-0 h-10 bg-or-akham flex items-center justify-around"
          >
            {[0, 1, 2, 3].map((i) => (
              <span
                key={i}
                className="w-6 h-6 bg-noir-salle"
                style={{ transform: 'skewX(-25deg)' }}
              />
            ))}
          </motion.div>
        </motion.div>

        <h2
          className="h-display text-or-akham mt-12"
          style={{ fontSize: 'clamp(72px, 12vw, 160px)' }}
        >
          Clap !
        </h2>
        <p className="text-ivoire-muted mt-6 max-w-md mx-auto">
          Votre pitch est en route. Akham vous répond sous 48h ouvrées.
        </p>
        <a href="/" className="btn-ghost mt-10 inline-flex">
          Retour à l’accueil
        </a>
      </div>
    </div>
  );
}
