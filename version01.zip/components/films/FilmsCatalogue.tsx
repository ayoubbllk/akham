'use client';

import { useState, useMemo } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import type { Film, FilmCategory } from '@/lib/types';
import { useMakingOf } from '@/components/providers/MakingOfProvider';

type FilterKey = 'all' | FilmCategory;

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'all', label: 'Tous' },
  { key: 'fiction', label: 'Fiction' },
  { key: 'documentaire', label: 'Documentaire' },
  { key: 'court-metrage', label: 'Court-métrage' },
  { key: 'developpement', label: 'En développement' },
];

const STATUS_LABEL: Record<string, string> = {
  sorti: 'Sorti',
  'post-production': 'Post-production',
  developpement: 'En développement',
};

const CAT_COLOR: Record<string, string> = {
  fiction: 'bg-fiction',
  documentaire: 'bg-documentaire',
  'court-metrage': 'bg-services-cat',
  developpement: 'bg-or-brule',
};

export function FilmsCatalogue({ films }: { films: Film[] }) {
  const [active, setActive] = useState<FilterKey>('all');
  const { active: makingOf } = useMakingOf();

  const filtered = useMemo(() => {
    if (active === 'all') return films;
    if (active === 'developpement') return films.filter((f) => f.status === 'developpement');
    return films.filter((f) => f.category === active);
  }, [active, films]);

  return (
    <section className="bg-noir-salle pb-32">
      {/* Filters sticky */}
      <div className="sticky top-20 z-30 bg-noir-salle/85 backdrop-blur-md border-b border-or-akham/10">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10 py-5 flex flex-wrap gap-2 md:gap-3">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              type="button"
              onClick={() => setActive(f.key)}
              className={`text-xs md:text-sm meta px-4 py-2 border transition-all ${
                active === f.key
                  ? 'bg-or-akham text-noir-salle border-or-akham'
                  : 'border-ivoire-ghost text-ivoire-muted hover:text-or-akham hover:border-or-akham'
              }`}
              aria-pressed={active === f.key}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Pellicule perforations */}
      <div className="hidden lg:block perforations h-6 opacity-60" />

      <div className="max-w-[1600px] mx-auto px-6 md:px-10 mt-10">
        {/* Mobile vertical grid */}
        <div className="grid lg:hidden grid-cols-1 md:grid-cols-2 gap-6">
          <AnimatePresence mode="popLayout">
            {filtered.map((film) => (
              <motion.div
                key={film.slug}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.4 }}
              >
                <FilmCard film={film} makingOfMode={makingOf} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Desktop horizontal pellicule */}
        <div className="hidden lg:block relative">
          <div className="snap-pellicule no-scrollbar overflow-x-auto pb-10">
            <div className="flex gap-8 min-w-max">
              <AnimatePresence mode="popLayout">
                {filtered.map((film) => (
                  <motion.div
                    key={film.slug}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.4 }}
                    className="w-[340px] shrink-0"
                  >
                    <FilmCard film={film} makingOfMode={makingOf} />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      <div className="hidden lg:block perforations h-6 opacity-60 mt-6" />
    </section>
  );
}

function FilmCard({ film, makingOfMode }: { film: Film; makingOfMode: boolean }) {
  const [hovered, setHovered] = useState(false);
  return (
    <Link
      href={`/films/${film.slug}`}
      data-cursor="image"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="group block"
    >
      <div className="relative aspect-affiche overflow-hidden bg-anthracite">
        <Image
          src={film.poster}
          alt={`Affiche ${film.title}`}
          fill
          sizes="(min-width: 1024px) 340px, (min-width: 640px) 50vw, 100vw"
          className={`object-cover transition-opacity duration-500 ${
            hovered || makingOfMode ? 'opacity-0' : 'opacity-100'
          }`}
        />
        <Image
          src={film.still}
          alt={`Still ${film.title}`}
          fill
          sizes="(min-width: 1024px) 340px, (min-width: 640px) 50vw, 100vw"
          className={`object-cover transition-opacity duration-500 ${
            hovered || makingOfMode ? 'opacity-100' : 'opacity-0'
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-noir-salle via-noir-salle/30 to-transparent opacity-90" />
        <span
          className={`absolute top-3 left-3 meta text-noir-salle px-2 py-1 ${CAT_COLOR[film.category]}`}
        >
          {film.category}
        </span>
        <span className="absolute bottom-3 right-3 meta text-ivoire bg-noir-salle/80 px-2 py-1">
          {STATUS_LABEL[film.status]}
        </span>
        <div className="absolute inset-x-0 bottom-0 p-5 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
          <p className="meta text-or-akham">
            {film.year} · {film.director}
          </p>
          <h3 className="h-display text-ivoire text-3xl mt-2 group-hover:text-or-akham transition-colors">
            {film.title}
          </h3>
          <p className="text-xs text-ivoire-muted mt-2 leading-relaxed line-clamp-2">
            {film.synopsisShort}
          </p>
        </div>
      </div>
    </Link>
  );
}
