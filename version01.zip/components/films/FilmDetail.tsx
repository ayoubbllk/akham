'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Play, X } from 'lucide-react';
import { useMakingOf } from '@/components/providers/MakingOfProvider';
import type { Film } from '@/lib/types';
import { VideoModal } from '@/components/VideoModal';

export function FilmDetail({ film }: { film: Film }) {
  const { active, toggle } = useMakingOf();
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [trailer, setTrailer] = useState(false);

  return (
    <article>
      {/* Hero CinemaScope */}
      <section className="relative h-[88vh] min-h-[560px] w-full overflow-hidden texture-grain">
        <Image
          src={film.still}
          alt={`Still ${film.title}`}
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-noir-salle/40 via-noir-salle/30 to-noir-salle" />

        <div className="relative z-10 h-full max-w-[1600px] mx-auto px-6 md:px-10 flex flex-col justify-end pb-20">
          <span className="meta">
            {film.year} · {film.category} · {film.duration}′ · Réalisation {film.director}
          </span>
          <h1
            className="h-display text-ivoire mt-6"
            style={{ fontSize: 'clamp(56px, 11vw, 160px)', lineHeight: 0.95 }}
          >
            {film.title.split('').map((c, i) => (
              <motion.span
                key={i}
                initial={{ y: 40, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.03 * i, duration: 0.6, ease: 'easeOut' }}
                className="inline-block"
              >
                {c === ' ' ? '\u00A0' : c}
              </motion.span>
            ))}
          </h1>
          {film.titleFr && (
            <p className="meta text-ivoire-muted mt-4">{film.titleFr}</p>
          )}

          <div className="mt-10 flex flex-wrap items-center gap-4">
            {film.trailerUrl && (
              <button
                type="button"
                data-cursor="video"
                onClick={() => setTrailer(true)}
                className="btn-or"
              >
                <Play size={16} fill="currentColor" /> Voir la bande-annonce
              </button>
            )}
            <button
              type="button"
              onClick={toggle}
              aria-pressed={active}
              className={`btn-ghost ${active ? '!border-or-akham !text-or-akham' : ''}`}
            >
              {active ? 'Quitter le making-of' : 'Mode making-of'}
            </button>
          </div>
        </div>
      </section>

      {/* Synopsis */}
      <Reveal>
        <section className="bg-noir-salle py-24">
          <div className="max-w-3xl mx-auto px-6 md:px-10">
            <span className="meta">Synopsis</span>
            <span className="gold-line mt-4 mb-8" />
            {film.synopsis.split('\n\n').map((p, i) => (
              <motion.p
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: i * 0.1 }}
                className="text-ivoire text-lg leading-relaxed mb-6"
              >
                {p}
              </motion.p>
            ))}
          </div>
        </section>
      </Reveal>

      {/* Galerie */}
      {film.gallery.length > 0 && (
        <Reveal>
          <section className="bg-[#0d0d0d] py-24">
            <div className="max-w-[1600px] mx-auto px-6 md:px-10">
              <span className="meta">Galerie</span>
              <h2 className="h-display text-ivoire text-4xl md:text-6xl mt-3 mb-12">
                Images
              </h2>
              <div className="columns-1 md:columns-2 lg:columns-3 gap-4 [column-fill:_balance]">
                {film.gallery.map((img, i) => {
                  const src = active && img.makingOf ? img.makingOf : img.src;
                  return (
                    <button
                      type="button"
                      key={i}
                      data-cursor="image"
                      onClick={() => setLightbox(src)}
                      className="block w-full mb-4 overflow-hidden bg-anthracite group break-inside-avoid"
                    >
                      <div className="relative w-full h-auto">
                        <Image
                          src={src}
                          alt={img.alt}
                          width={1200}
                          height={800}
                          sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
                          className="w-full h-auto object-cover group-hover:scale-105 transition-transform duration-700"
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </section>
        </Reveal>
      )}

      {/* Équipe */}
      <Reveal>
        <section className="bg-noir-salle py-24">
          <div className="max-w-[1600px] mx-auto px-6 md:px-10">
            <span className="meta">Équipe du film</span>
            <span className="gold-line mt-4 mb-12" />
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-8 gap-y-6">
              {film.crew.map((c) => (
                <div key={c.role + c.name} className="border-l border-or-akham/30 pl-4">
                  <p className="meta text-ivoire-muted">{c.role}</p>
                  <p className="text-ivoire text-lg mt-1">{c.name}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </Reveal>

      {/* Fiche technique */}
      <Reveal>
        <section className="bg-[#0d0d0d] py-24">
          <div className="max-w-3xl mx-auto px-6 md:px-10">
            <span className="meta">Fiche technique</span>
            <span className="gold-line mt-4 mb-8" />
            <table className="w-full font-mono text-sm">
              <tbody>
                <Row label="Titre" value={film.title} />
                {film.titleFr && <Row label="Titre français" value={film.titleFr} />}
                <Row label="Année" value={String(film.year)} />
                <Row label="Catégorie" value={film.category} />
                <Row label="Durée" value={`${film.duration} minutes`} />
                <Row label="Réalisation" value={film.director} />
                <Row label="Production" value="Akham Films" />
                <Row label="Statut" value={film.status} />
              </tbody>
            </table>
          </div>
        </section>
      </Reveal>

      {/* Festivals */}
      {film.festivals && film.festivals.length > 0 && (
        <Reveal>
          <section className="bg-noir-salle py-24">
            <div className="max-w-[1600px] mx-auto px-6 md:px-10">
              <span className="meta">Festivals & prix</span>
              <span className="gold-line mt-4 mb-12" />
              <div className="overflow-x-auto no-scrollbar">
                <ol className="flex gap-6 min-w-max">
                  {film.festivals.map((f, i) => (
                    <li
                      key={i}
                      className="w-72 shrink-0 border border-or-akham/20 p-6 bg-anthracite"
                    >
                      <div className="meta text-or-akham">{f.year}</div>
                      <h4 className="font-display text-ivoire text-2xl mt-3">
                        {f.name}
                      </h4>
                      {f.award && (
                        <p className="text-sm text-ivoire-muted mt-3">{f.award}</p>
                      )}
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </section>
        </Reveal>
      )}

      {film.trailerUrl && (
        <VideoModal
          open={trailer}
          onClose={() => setTrailer(false)}
          src={film.trailerUrl}
          title={`${film.title} — bande-annonce`}
        />
      )}

      {/* Lightbox */}
      {lightbox && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-[100] bg-noir-salle/95 flex items-center justify-center p-6"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            aria-label="Fermer"
            onClick={() => setLightbox(null)}
            className="absolute top-6 right-6 text-ivoire hover:text-or-akham"
          >
            <X size={28} />
          </button>
          <div className="relative max-w-[90vw] max-h-[85vh]">
            <Image
              src={lightbox}
              alt=""
              width={1920}
              height={1280}
              className="object-contain max-h-[85vh] w-auto"
            />
          </div>
        </div>
      )}
    </article>
  );
}

function Reveal({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
    >
      {children}
    </motion.div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <tr className="border-b border-ivoire-ghost">
      <td className="py-3 pr-4 text-ivoire-muted uppercase tracking-wider text-xs w-1/3">
        {label}
      </td>
      <td className="py-3 text-ivoire">{value}</td>
    </tr>
  );
}
