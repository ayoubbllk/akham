'use client';

import { animate, useInView } from 'framer-motion';
import { useEffect, useRef, useState } from 'react';

const STATS = [
  { value: 7, suffix: '+', label: 'Années d’existence' },
  { value: 24, suffix: '', label: 'Projets réalisés' },
  { value: 9, suffix: '', label: 'Pays de coproduction' },
  { value: 38, suffix: '', label: 'Sélections en festivals' },
];

function Counter({ to, suffix }: { to: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });
  const [v, setV] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, to, {
      duration: 1.6,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (val) => setV(Math.round(val)),
    });
    return () => controls.stop();
  }, [inView, to]);

  return (
    <span ref={ref}>
      {v}
      {suffix}
    </span>
  );
}

export function Stats() {
  return (
    <section className="bg-noir-salle py-24 md:py-32">
      <div className="max-w-[1600px] mx-auto px-6 md:px-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-10">
          {STATS.map((s) => (
            <div key={s.label} className="text-left">
              <div
                className="font-display text-or-akham"
                style={{ fontSize: 'clamp(48px, 6vw, 96px)', lineHeight: 1 }}
              >
                <Counter to={s.value} suffix={s.suffix} />
              </div>
              <p className="meta text-ivoire-muted mt-4">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
