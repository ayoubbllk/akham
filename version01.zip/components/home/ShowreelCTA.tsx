'use client';

import { useState } from 'react';
import { Play } from 'lucide-react';
import { motion } from 'framer-motion';
import { VideoModal } from '@/components/VideoModal';

export function ShowreelCTA() {
  const [open, setOpen] = useState(false);
  return (
    <section className="relative bg-noir-salle py-32 md:py-44 texture-grain overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-6 md:px-10 text-center relative z-10">
        <span className="meta">Akham Reel 2026</span>
        <motion.button
          type="button"
          onClick={() => setOpen(true)}
          data-cursor="video"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="block mx-auto mt-8 group"
          aria-label="Lancer le showreel complet"
        >
          <span
            className="h-display block text-ivoire group-hover:text-or-akham transition-colors"
            style={{ fontSize: 'clamp(48px, 8vw, 130px)', lineHeight: 1 }}
          >
            Voir le showreel
          </span>
          <span className="mt-8 inline-flex items-center justify-center w-20 h-20 rounded-full border-2 border-or-akham group-hover:bg-or-akham transition-all">
            <Play size={32} className="text-or-akham group-hover:text-noir-salle transition-colors fill-current" />
          </span>
        </motion.button>
      </div>

      <VideoModal
        open={open}
        onClose={() => setOpen(false)}
        src="https://cdn.coverr.co/videos/coverr-cinematic-camera-on-the-set-1572/1080p.mp4"
        title="Akham Films — Showreel 2026"
      />
    </section>
  );
}
