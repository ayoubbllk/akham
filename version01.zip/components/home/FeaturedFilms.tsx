'use client';

import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { featuredFilms } from '@/data/films';
import { FilmImage } from '@/components/FilmImage';
import type { Film } from '@/lib/types';

const CAT_COLOR: Record<string, string> = {
  fiction: 'bg-fiction',
  documentaire: 'bg-documentaire',
  'court-metrage': 'bg-services-cat',
  developpement: 'bg-or-brule',
};

const CAT_LABEL: Record<string, string> = {
  fiction: 'Fiction',
  documentaire: 'Documentaire',
  'court-metrage': 'Court-métrage',
  developpement: 'Développement',
};

export function FeaturedFilms() {
  const films: Film[] = featuredFilms();

  return (
    <section className="relative py-28 md:py-36 bg-noir-salle">
      <div className="max-w-[1600px] mx-auto px-6 md:px-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <span className="meta">Sélection</span>
            <h2 className="h-display text-ivoire mt-3 text-5xl md:text-7xl">
              Projets en vedette
            </h2>
            <span className="gold-line mt-6" />
          </div>
          <Link href="/films" data-cursor="cta" className="btn-ghost self-start md:self-auto">
            Voir tous les films <ArrowUpRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {films.map((film, i) => (
            <motion.div
              key={film.slug}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.7, delay: i * 0.1 }}
            >
              <Link
                href={`/films/${film.slug}`}
                data-cursor="image"
                className="group block relative"
              >
                <div className="relative aspect-cinema overflow-hidden bg-anthracite">
                  <FilmImage
                    src={film.still}
                    alt={film.title}
                    fill
                    sizes="(min-width: 768px) 33vw, 100vw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-noir-salle/95 via-noir-salle/30 to-transparent" />
                  <span
                    className={`absolute top-4 left-4 meta text-noir-salle px-2 py-1 ${
                      CAT_COLOR[film.category] || 'bg-or-akham'
                    }`}
                  >
                    {CAT_LABEL[film.category]}
                  </span>
                  <div className="absolute inset-x-0 bottom-0 p-5 md:p-6 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                    <span className="meta text-ivoire-muted">
                      {film.year} · {film.director}
                    </span>
                    <h3 className="h-display text-ivoire text-3xl md:text-4xl mt-2 group-hover:text-or-akham transition-colors">
                      {film.title}
                    </h3>
                    <p className="text-sm text-ivoire-muted mt-2 max-w-md opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      {film.synopsisShort}
                    </p>
                  </div>
                  <div className="absolute inset-0 bg-or-akham/0 group-hover:bg-or-akham/10 transition-colors duration-500" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
