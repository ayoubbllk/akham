'use client';

import Link from 'next/link';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ChevronDown } from 'lucide-react';
import { HeroCountdown } from './HeroCountdown';
import { useStudioLive } from '@/components/providers/StudioLiveProvider';

export function HomeHero() {
  const [ready, setReady] = useState(false);
  const { active: studioLive } = useStudioLive();

  return (
    <section className="relative h-screen min-h-[680px] w-full overflow-hidden texture-grain bg-noir-salle">
      <HeroCountdown onDone={() => setReady(true)} />

      {/* Showreel background */}
      <video
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        className="absolute inset-0 w-full h-full object-cover"
        poster="https://images.unsplash.com/photo-1542204165-65bf26472b9b?auto=format&fit=crop&w=1920&q=80"
      >
        <source
          src="https://cdn.coverr.co/videos/coverr-cinematic-camera-on-the-set-1572/1080p.mp4"
          type="video/mp4"
        />
      </video>

      {/* Overlay */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(to bottom, rgba(8,8,8,0.30) 0%, rgba(8,8,8,0.85) 100%)',
        }}
      />

      {/* Content */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={ready ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8, ease: 'easeOut', staggerChildren: 0.05 }}
        className="relative z-10 h-full max-w-[1600px] mx-auto px-6 md:px-10 flex flex-col justify-end pb-32"
      >
        <span className="meta">Algérie · Depuis 2019 · Production cinématographique</span>

        <h1
          className="h-display mt-6 text-ivoire"
          style={{ fontSize: 'clamp(48px, 9vw, 120px)' }}
        >
          <motion.span
            className="block"
            initial={{ y: 60, opacity: 0 }}
            animate={ready ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.1 }}
          >
            Des histoires
          </motion.span>
          <motion.span
            className="block text-or-akham"
            initial={{ y: 60, opacity: 0 }}
            animate={ready ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            qui illuminent
          </motion.span>
          <motion.span
            className="block"
            initial={{ y: 60, opacity: 0 }}
            animate={ready ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            l’Algérie.
          </motion.span>
        </h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={ready ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-8 max-w-xl text-ivoire-muted text-base md:text-lg leading-relaxed"
        >
          Société de production fondée par Youcef Mansour. Documentaires,
          fiction et services audiovisuels. Depuis Alger, vers le monde.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={ready ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.65 }}
          className="mt-10 flex flex-wrap gap-4"
        >
          <Link href="/films" data-cursor="cta" className="btn-or">
            Découvrir nos films <ArrowUpRight size={16} />
          </Link>
          <Link href="/pitch" data-cursor="cta" className="btn-ghost">
            Pitcher un projet
          </Link>
        </motion.div>
      </motion.div>

      {/* Live badge */}
      {studioLive && (
        <div className="absolute bottom-8 left-6 md:left-10 z-10 flex items-center gap-2 meta text-live-red">
          <span className="live-dot" /> Studio actif
        </div>
      )}

      {/* Scroll indicator */}
      <div className="absolute bottom-8 right-6 md:right-10 z-10 flex flex-col items-center gap-3">
        <span className="meta text-ivoire-muted [writing-mode:vertical-rl] rotate-180">
          Défiler
        </span>
        <div className="relative w-px h-16 bg-ivoire-ghost overflow-hidden">
          <span className="absolute inset-x-0 top-0 h-8 bg-or-akham animate-scroll-down" />
        </div>
        <ChevronDown size={14} className="text-or-akham" />
      </div>
    </section>
  );
}
