'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import * as Icons from 'lucide-react';
import { services } from '@/data/services';

export function ServicesPreview() {
  const top = services.slice(0, 6);
  return (
    <section className="relative bg-anthracite texture-points py-28 md:py-36 overflow-hidden">
      <div className="max-w-[1600px] mx-auto px-6 md:px-10 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <span className="meta">Services</span>
            <h2 className="h-display text-ivoire mt-3 text-5xl md:text-7xl">
              Une maison, <span className="text-or-akham">huit métiers</span>
            </h2>
            <span className="gold-line mt-6" />
          </div>
          <Link href="/services" data-cursor="cta" className="btn-ghost self-start md:self-auto">
            Explorer nos services <ArrowUpRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-anthracite-2">
          {top.map((s, i) => {
            const Icon = (Icons[s.icon as keyof typeof Icons] as Icons.LucideIcon) || Icons.Sparkles;
            return (
              <motion.div
                key={s.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                className="group bg-anthracite p-8 md:p-10 hover:bg-or-akham/5 transition-colors duration-500"
              >
                <Icon
                  size={36}
                  className="text-or-akham group-hover:scale-110 transition-transform duration-500"
                  strokeWidth={1.2}
                />
                <h3 className="h-display text-ivoire text-2xl md:text-3xl mt-6 group-hover:text-or-akham transition-colors">
                  {s.title}
                </h3>
                <p className="text-sm text-ivoire-muted mt-3 leading-relaxed">
                  {s.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
