'use client';

import { motion } from 'framer-motion';

export function Manifesto() {
  return (
    <section className="relative bg-[#0d0d0d] texture-pellicule py-32 md:py-44 overflow-hidden">
      <div className="max-w-5xl mx-auto px-6 md:px-10 text-center relative z-10">
        <span className="meta">Manifeste</span>
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.9, ease: [0.76, 0, 0.24, 1] }}
          className="h-display text-ivoire mt-6"
          style={{ fontSize: 'clamp(36px, 5.2vw, 72px)', lineHeight: 1.05 }}
        >
          « Nous ne faisons pas des films.
          <br />
          <span className="text-or-akham">Nous allumons des lumières.</span> »
        </motion.h2>
        <p className="mt-10 text-ivoire-muted max-w-2xl mx-auto text-base md:text-lg leading-relaxed">
          Akham — la maison, en kabyle. Un toit pour les histoires algériennes,
          un atelier pour celles et ceux qui croient encore au pouvoir d’un cadre
          tenu juste.
        </p>
      </div>
    </section>
  );
}
