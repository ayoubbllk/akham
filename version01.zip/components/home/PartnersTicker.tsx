'use client';

const PARTNERS = [
  'AARC',
  'CADC',
  'Arte France',
  'France 24',
  'Doha Film Institute',
  'AFAC',
  'Red Sea Fund',
  'CNC',
  'JCC Carthage',
  'FESPACO',
  'BeIN',
  'Algérie Télécom',
];

export function PartnersTicker() {
  // Duplicate for seamless loop
  const list = [...PARTNERS, ...PARTNERS];
  return (
    <section className="bg-[#0d0d0d] py-16 border-y border-or-akham/15 overflow-hidden">
      <div className="text-center mb-10">
        <span className="meta">Ils nous font confiance</span>
      </div>
      <div className="overflow-hidden">
        <div className="marquee">
          {list.map((p, i) => (
            <div
              key={`${p}-${i}`}
              className="px-12 flex items-center justify-center shrink-0"
            >
              <span className="font-display text-3xl md:text-4xl text-ivoire-muted hover:text-or-akham transition-colors tracking-wider whitespace-nowrap">
                {p}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
