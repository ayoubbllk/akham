'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Film, Tv, Camera, Mic } from 'lucide-react';

type ProjectType = 'fiction' | 'documentaire' | 'pub' | 'photo';
type Format = 'court' | 'long' | 'serie' | 'spot';
type Finition = 'standard' | 'premium' | 'cinema';

const TYPES: { key: ProjectType; label: string; icon: React.ReactNode; mult: number }[] = [
  { key: 'fiction', label: 'Fiction', icon: <Film />, mult: 1.6 },
  { key: 'documentaire', label: 'Documentaire', icon: <Tv />, mult: 1 },
  { key: 'pub', label: 'Publicité / Brand', icon: <Mic />, mult: 1.3 },
  { key: 'photo', label: 'Studio photo', icon: <Camera />, mult: 0.4 },
];

const FORMATS: { key: Format; label: string; mult: number }[] = [
  { key: 'court', label: 'Court (≤ 30 min)', mult: 1 },
  { key: 'long', label: 'Long (≥ 60 min)', mult: 2.4 },
  { key: 'serie', label: 'Série (par épisode)', mult: 1.8 },
  { key: 'spot', label: 'Spot (≤ 90 sec)', mult: 0.6 },
];

const FINITIONS: { key: Finition; label: string; mult: number }[] = [
  { key: 'standard', label: 'Standard', mult: 1 },
  { key: 'premium', label: 'Premium', mult: 1.6 },
  { key: 'cinema', label: 'Niveau cinéma', mult: 2.5 },
];

const BASE = 1_500_000; // DA

const fmt = (n: number) =>
  new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 }).format(n);

export function BudgetEstimator() {
  const [step, setStep] = useState(0);
  const [type, setType] = useState<ProjectType | null>(null);
  const [format, setFormat] = useState<Format | null>(null);
  const [finition, setFinition] = useState<Finition | null>(null);

  const can = step === 0 ? !!type : step === 1 ? !!format : !!finition;

  const min =
    type && format && finition
      ? BASE *
        TYPES.find((t) => t.key === type)!.mult *
        FORMATS.find((f) => f.key === format)!.mult *
        FINITIONS.find((f) => f.key === finition)!.mult *
        0.7
      : 0;
  const max = min ? min * 1.9 : 0;

  return (
    <section
      id="estimateur"
      className="bg-anthracite border-y border-or-akham/20 py-24 md:py-32"
    >
      <div className="max-w-3xl mx-auto px-6 md:px-10">
        <span className="meta">Estimateur de budget</span>
        <h2 className="h-display text-ivoire text-4xl md:text-6xl mt-3">
          Une <span className="text-or-akham">fourchette</span> en 3 questions
        </h2>
        <p className="mt-4 text-ivoire-muted text-sm max-w-xl">
          Indication seulement. Pour un devis précis, parlez-nous de votre projet
          via la page Pitch.
        </p>

        <div className="mt-12 bg-noir-salle p-6 md:p-10 border border-or-akham/15">
          <div className="flex items-center gap-2 mb-8">
            {[0, 1, 2, 3].map((i) => (
              <span
                key={i}
                className={`h-1 flex-1 ${
                  i <= step ? 'bg-or-akham' : 'bg-anthracite-2'
                }`}
              />
            ))}
          </div>

          {step === 0 && (
            <Step title="Quel type de projet ?">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {TYPES.map((t) => (
                  <Pill
                    key={t.key}
                    active={type === t.key}
                    onClick={() => setType(t.key)}
                    icon={t.icon}
                    label={t.label}
                  />
                ))}
              </div>
            </Step>
          )}

          {step === 1 && (
            <Step title="Quel format ?">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {FORMATS.map((f) => (
                  <Pill
                    key={f.key}
                    active={format === f.key}
                    onClick={() => setFormat(f.key)}
                    label={f.label}
                  />
                ))}
              </div>
            </Step>
          )}

          {step === 2 && (
            <Step title="Quel niveau de finition ?">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {FINITIONS.map((f) => (
                  <Pill
                    key={f.key}
                    active={finition === f.key}
                    onClick={() => setFinition(f.key)}
                    label={f.label}
                  />
                ))}
              </div>
            </Step>
          )}

          {step === 3 && (
            <Step title="Estimation indicative">
              <div className="text-center py-8">
                <div className="meta text-ivoire-muted">Fourchette</div>
                <div
                  className="font-display text-or-akham mt-3"
                  style={{ fontSize: 'clamp(40px, 6vw, 84px)', lineHeight: 1 }}
                >
                  {fmt(min)} – {fmt(max)} DA
                </div>
                <a
                  href="/pitch"
                  data-cursor="cta"
                  className="btn-or mt-10 inline-flex"
                >
                  Demander un devis précis <ArrowRight size={16} />
                </a>
              </div>
            </Step>
          )}

          {step < 3 && (
            <div className="flex justify-between mt-10">
              <button
                type="button"
                onClick={() => setStep((s) => Math.max(0, s - 1))}
                disabled={step === 0}
                className="meta text-ivoire-muted disabled:opacity-30 hover:text-or-akham transition-colors"
              >
                ← Retour
              </button>
              <button
                type="button"
                onClick={() => setStep((s) => s + 1)}
                disabled={!can}
                className="btn-or disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Continuer <ArrowRight size={16} />
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function Step({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <motion.div
      key={title}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <h3 className="h-display text-ivoire text-2xl md:text-3xl mb-6">{title}</h3>
      {children}
    </motion.div>
  );
}

function Pill({
  active,
  onClick,
  label,
  icon,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  icon?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`p-4 border text-left transition-all ${
        active
          ? 'border-or-akham bg-or-akham/10 text-or-akham'
          : 'border-ivoire-ghost text-ivoire hover:border-or-akham hover:text-or-akham'
      }`}
      aria-pressed={active}
    >
      {icon && <span className="block mb-2 [&>svg]:w-5 [&>svg]:h-5">{icon}</span>}
      <span className="text-sm font-medium tracking-wide">{label}</span>
    </button>
  );
}
