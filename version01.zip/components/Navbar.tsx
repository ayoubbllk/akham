'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { useStudioLive } from '@/components/providers/StudioLiveProvider';
import { cn } from '@/lib/utils';

const NAV = [
  { href: '/films', label: 'Films' },
  { href: '/services', label: 'Services' },
  { href: '/studio', label: 'Studio' },
  { href: '/equipe', label: 'Équipe' },
  { href: '/blog', label: 'Journal' },
  { href: '/contact', label: 'Contact' },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { active: studioLive } = useStudioLive();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <>
      <header
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
          scrolled
            ? 'bg-noir-salle/90 backdrop-blur-md border-b border-or-akham/15'
            : 'bg-transparent'
        )}
      >
        <nav className="max-w-[1600px] mx-auto px-6 md:px-10 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3" aria-label="Akham Films — accueil">
            <span className="font-display text-3xl tracking-wider text-or-akham leading-none">
              AKHAM
            </span>
            <span className="font-display text-3xl tracking-wider text-ivoire leading-none">
              FILMS
            </span>
            {studioLive && (
              <span className="hidden md:flex items-center gap-2 ml-4 meta text-live-red">
                <span className="live-dot" /> LIVE
              </span>
            )}
          </Link>

          <ul className="hidden lg:flex items-center gap-9">
            {NAV.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="link-or text-sm tracking-wider uppercase font-medium"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-4">
            <Link
              href="/pitch"
              data-cursor="cta"
              className="hidden md:inline-flex btn-or"
              aria-label="Pitcher un projet"
            >
              Collaborer <ArrowUpRight size={16} />
            </Link>
            <button
              type="button"
              aria-label={open ? 'Fermer le menu' : 'Ouvrir le menu'}
              onClick={() => setOpen((v) => !v)}
              className="lg:hidden p-2 text-ivoire"
            >
              {open ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-40 bg-noir-salle lg:hidden"
          >
            <div className="h-20" />
            <ul className="flex flex-col gap-4 p-10">
              {NAV.map((item, i) => (
                <motion.li
                  key={item.href}
                  initial={{ x: -30, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.05 * i, duration: 0.3 }}
                >
                  <Link
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className="font-display text-5xl tracking-wider text-ivoire hover:text-or-akham transition-colors"
                  >
                    {item.label}
                  </Link>
                </motion.li>
              ))}
              <motion.li
                initial={{ x: -30, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.4, duration: 0.3 }}
                className="mt-8"
              >
                <Link href="/pitch" onClick={() => setOpen(false)} className="btn-or">
                  Collaborer <ArrowUpRight size={16} />
                </Link>
              </motion.li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
