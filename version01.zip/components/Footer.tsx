'use client';

import Link from 'next/link';
import { Instagram, Linkedin, Youtube, Video } from 'lucide-react';
import { SITE } from '@/lib/utils';
import { useMakingOf } from '@/components/providers/MakingOfProvider';

const COLS = [
  {
    title: 'Studio',
    links: [
      { href: '/films', label: 'Films' },
      { href: '/services', label: 'Services' },
      { href: '/studio', label: 'Le studio' },
      { href: '/equipe', label: 'Équipe' },
    ],
  },
  {
    title: 'Travailler ensemble',
    links: [
      { href: '/pitch', label: 'Pitcher un projet' },
      { href: '/services#estimateur', label: 'Estimer un budget' },
      { href: '/contact', label: 'Réserver le studio' },
      { href: '/contact', label: 'Presse' },
    ],
  },
  {
    title: 'Lire & écouter',
    links: [
      { href: '/blog', label: 'Journal de production' },
      { href: '/blog?cat=fonds', label: 'Aides & fonds' },
      { href: '/blog?cat=interview', label: 'Entretiens' },
      { href: '/blog?cat=coulisses', label: 'Coulisses' },
    ],
  },
  {
    title: 'Akham Films',
    links: [
      { href: '/contact', label: 'Contact' },
      { href: '/mentions-legales', label: 'Mentions légales' },
      { href: '/confidentialite', label: 'Confidentialité' },
    ],
  },
];

export function Footer() {
  const { active, toggle } = useMakingOf();

  return (
    <footer className="relative bg-[#0d0d0d] border-t border-or-akham/20 mt-32">
      <div className="max-w-[1600px] mx-auto px-6 md:px-10 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2">
              <span className="font-display text-3xl text-or-akham">AKHAM</span>
              <span className="font-display text-3xl text-ivoire">FILMS</span>
            </Link>
            <p className="mt-5 text-ivoire-muted text-sm max-w-sm leading-relaxed">
              Société de production cinématographique algérienne fondée en {SITE.founded}.
              Documentaires, fiction et services audiovisuels.
            </p>
            <div className="mt-6 flex items-center gap-3">
              <a
                href={SITE.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="p-2 border border-ivoire-ghost hover:border-or-akham hover:text-or-akham transition-colors"
              >
                <Instagram size={16} />
              </a>
              <a
                href={SITE.social.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                className="p-2 border border-ivoire-ghost hover:border-or-akham hover:text-or-akham transition-colors"
              >
                <Linkedin size={16} />
              </a>
              <a
                href={SITE.social.youtube}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube"
                className="p-2 border border-ivoire-ghost hover:border-or-akham hover:text-or-akham transition-colors"
              >
                <Youtube size={16} />
              </a>
              <a
                href={SITE.social.vimeo}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Vimeo"
                className="p-2 border border-ivoire-ghost hover:border-or-akham hover:text-or-akham transition-colors"
              >
                <Video size={16} />
              </a>
            </div>
          </div>

          {COLS.map((col) => (
            <div key={col.title}>
              <h4 className="meta mb-5">{col.title}</h4>
              <ul className="space-y-3">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <Link
                      href={l.href}
                      className="text-sm text-ivoire-muted hover:text-or-akham transition-colors"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-16 pt-8 border-t border-ivoire-ghost flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <p className="text-xs text-ivoire-muted">
            © {new Date().getFullYear()} Akham Films · {SITE.city}, {SITE.country}. Tous droits réservés.
          </p>
          <button
            type="button"
            onClick={toggle}
            className="text-xs meta flex items-center gap-2 text-ivoire-ghost hover:text-or-akham transition-colors"
            aria-pressed={active}
            title="Bascule l'ensemble du site en version coulisses"
          >
            <span
              className={`inline-block w-8 h-4 rounded-full relative transition-colors ${
                active ? 'bg-or-akham' : 'bg-anthracite-2'
              }`}
            >
              <span
                className={`absolute top-0.5 w-3 h-3 rounded-full bg-noir-salle transition-all ${
                  active ? 'left-[18px]' : 'left-0.5'
                }`}
              />
            </span>
            Making-of mode
          </button>
        </div>
      </div>
    </footer>
  );
}
