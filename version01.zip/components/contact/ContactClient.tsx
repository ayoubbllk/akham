'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion } from 'framer-motion';
import { Send, MapPin, Mail, Phone, Instagram, Linkedin, Youtube } from 'lucide-react';
import { SITE } from '@/lib/utils';
import { useStudioLive } from '@/components/providers/StudioLiveProvider';

const Schema = z.object({
  name: z.string().min(2, 'Votre nom est requis'),
  email: z.string().email('Email invalide'),
  subject: z.enum(['coproduction', 'service', 'presse', 'autre']),
  message: z.string().min(10, 'Un peu plus de détails ?'),
});

type FormData = z.infer<typeof Schema>;

export function ContactClient() {
  const { active } = useStudioLive();
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({ resolver: zodResolver(Schema) });

  const onSubmit = async (data: FormData) => {
    setError(null);
    try {
      const r = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!r.ok) throw new Error('Échec de l’envoi');
      setSent(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Erreur');
    }
  };

  return (
    <section className="bg-noir-salle pt-32 pb-32">
      <div className="max-w-[1400px] mx-auto px-6 md:px-10">
        <span className="meta">Akham Films · Alger</span>
        <h1 className="h-display text-ivoire mt-4 text-6xl md:text-8xl">
          Travaillons <span className="text-or-akham">ensemble</span>
        </h1>
        <span className="gold-line mt-6" />

        <div className="mt-20 grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Left */}
          <div>
            <div className="space-y-6">
              <Info icon={<MapPin />} label="Adresse" value={SITE.address} />
              <Info icon={<Mail />} label="Email" value={SITE.email} href={`mailto:${SITE.email}`} />
              <Info icon={<Phone />} label="Téléphone" value={SITE.phone} href={`tel:${SITE.phone.replace(/\s/g, '')}`} />
            </div>

            <div className="mt-10 flex gap-3">
              <a href={SITE.social.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                className="p-3 border border-ivoire-ghost hover:border-or-akham hover:text-or-akham transition-colors">
                <Instagram size={18} />
              </a>
              <a href={SITE.social.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn"
                className="p-3 border border-ivoire-ghost hover:border-or-akham hover:text-or-akham transition-colors">
                <Linkedin size={18} />
              </a>
              <a href={SITE.social.youtube} target="_blank" rel="noopener noreferrer" aria-label="YouTube"
                className="p-3 border border-ivoire-ghost hover:border-or-akham hover:text-or-akham transition-colors">
                <Youtube size={18} />
              </a>
            </div>

            <div
              className={`mt-10 inline-flex items-center gap-3 px-5 py-3 border ${
                active ? 'border-live-red text-live-red' : 'border-documentaire text-documentaire'
              }`}
            >
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  active ? 'bg-live-red shadow-[0_0_12px_rgba(226,75,74,0.8)] animate-blink' : 'bg-documentaire'
                }`}
              />
              <span className="meta">{active ? 'Studio actif' : 'Studio disponible'}</span>
            </div>

            {/* Map placeholder */}
            <div className="mt-12 relative aspect-video bg-anthracite border border-or-akham/20 overflow-hidden">
              <iframe
                title="Carte Akham Films Alger"
                src="https://www.openstreetmap.org/export/embed.html?bbox=2.95,36.70,3.15,36.82&layer=mapnik&marker=36.7538,3.0588"
                className="w-full h-full grayscale contrast-125 opacity-80"
                loading="lazy"
              />
            </div>
          </div>

          {/* Right - form */}
          <div>
            {sent ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="border border-or-akham p-10 text-center"
              >
                <h3 className="h-display text-or-akham text-4xl">Message envoyé</h3>
                <p className="text-ivoire-muted mt-4">
                  Merci. Nous revenons vers vous sous 48h ouvrées.
                </p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
                <FormField label="Nom" error={errors.name?.message}>
                  <input
                    type="text"
                    {...register('name')}
                    className="block w-full bg-transparent border-b border-ivoire-ghost focus:border-or-akham outline-none text-ivoire text-lg py-3"
                  />
                </FormField>
                <FormField label="Email" error={errors.email?.message}>
                  <input
                    type="email"
                    {...register('email')}
                    className="block w-full bg-transparent border-b border-ivoire-ghost focus:border-or-akham outline-none text-ivoire text-lg py-3"
                  />
                </FormField>
                <FormField label="Sujet" error={errors.subject?.message}>
                  <select
                    {...register('subject')}
                    defaultValue=""
                    className="block w-full bg-transparent border-b border-ivoire-ghost focus:border-or-akham outline-none text-ivoire text-lg py-3"
                  >
                    <option value="" disabled className="bg-noir-salle">— Choisir —</option>
                    <option value="coproduction" className="bg-noir-salle">Coproduction</option>
                    <option value="service" className="bg-noir-salle">Service</option>
                    <option value="presse" className="bg-noir-salle">Presse</option>
                    <option value="autre" className="bg-noir-salle">Autre</option>
                  </select>
                </FormField>
                <FormField label="Message" error={errors.message?.message}>
                  <textarea
                    rows={5}
                    {...register('message')}
                    className="block w-full bg-transparent border-b border-ivoire-ghost focus:border-or-akham outline-none text-ivoire text-lg py-3 resize-none"
                  />
                </FormField>

                {error && <p className="text-live-red text-sm meta">{error}</p>}

                <button type="submit" disabled={isSubmitting} className="btn-or" data-cursor="cta">
                  {isSubmitting ? 'Envoi…' : 'Envoyer'} <Send size={16} />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function Info({
  icon,
  label,
  value,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  href?: string;
}) {
  const Inner = (
    <div className="flex items-start gap-4">
      <span className="text-or-akham mt-1 [&>svg]:w-5 [&>svg]:h-5">{icon}</span>
      <div>
        <p className="meta text-ivoire-muted">{label}</p>
        <p className="text-ivoire text-lg mt-1">{value}</p>
      </div>
    </div>
  );
  return href ? (
    <a href={href} className="block hover:text-or-akham transition-colors">
      {Inner}
    </a>
  ) : (
    Inner
  );
}

function FormField({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="meta text-ivoire-muted">{label}</span>
      {children}
      {error && <p className="mt-2 text-live-red text-xs meta">{error}</p>}
    </label>
  );
}
