'use client';

import { useStudioLive } from '@/components/providers/StudioLiveProvider';

export function StudioStatus() {
  const { active } = useStudioLive();

  return (
    <section className="bg-[#0d0d0d] py-20 border-y border-or-akham/15">
      <div className="max-w-[1600px] mx-auto px-6 md:px-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <span className="meta">Studio en direct</span>
          <h3 className="h-display text-ivoire text-3xl md:text-5xl mt-3">
            {active ? 'Tournage en cours' : 'Studio disponible'}
          </h3>
          <p className="text-ivoire-muted text-sm mt-3 max-w-xl">
            {active
              ? 'Le studio est actuellement utilisé pour un tournage. Réservations possibles à partir de la semaine prochaine.'
              : 'Aucune production en cours — créneau disponible immédiatement.'}
          </p>
        </div>
        <div
          className={`flex items-center gap-3 px-5 py-3 border ${
            active ? 'border-live-red text-live-red' : 'border-documentaire text-documentaire'
          }`}
        >
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              active ? 'bg-live-red animate-blink shadow-[0_0_12px_rgba(226,75,74,0.8)]' : 'bg-documentaire'
            }`}
          />
          <span className="meta">{active ? 'Live · Plateau actif' : 'Disponible'}</span>
        </div>
      </div>
    </section>
  );
}
