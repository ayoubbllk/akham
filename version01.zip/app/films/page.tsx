import type { Metadata } from 'next';
import { films } from '@/data/films';
import { FilmsCatalogue } from '@/components/films/FilmsCatalogue';

export const metadata: Metadata = {
  title: 'Nos films',
  description:
    'Catalogue des films produits par Akham Films : documentaires, fictions et courts-métrages.',
};

export default function FilmsPage() {
  return (
    <>
      <header className="pt-40 pb-16 bg-noir-salle">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          <span className="meta">Catalogue · {films.length} titres</span>
          <h1 className="h-display text-ivoire mt-4 text-6xl md:text-8xl">
            Nos <span className="text-or-akham">films</span>
          </h1>
          <span className="gold-line mt-6" />
          <p className="mt-8 text-ivoire-muted max-w-2xl">
            Documentaires, fictions, courts-métrages. Tous les films produits ou coproduits
            par Akham Films depuis 2019.
          </p>
        </div>
      </header>

      <FilmsCatalogue films={films} />
    </>
  );
}
