import Link from 'next/link';

export default function NotFound() {
  return (
    <section className="min-h-screen flex items-center justify-center text-center px-6">
      <div>
        <p className="meta">Erreur 404</p>
        <h1
          className="h-display text-or-akham mt-4"
          style={{ fontSize: 'clamp(80px, 14vw, 200px)' }}
        >
          Coupez !
        </h1>
        <p className="text-ivoire-muted mt-4 max-w-md mx-auto">
          La scène que vous cherchez n’existe pas — ou n’a pas encore été tournée.
        </p>
        <Link href="/" className="btn-or mt-10 inline-flex">
          Retour à la salle
        </Link>
      </div>
    </section>
  );
}
