import type { Metadata } from 'next';
import Image from 'next/image';
import { team, founder, values } from '@/data/team';

export const metadata: Metadata = {
  title: 'Équipe',
  description: 'Les visages d’Akham Films : fondateur, équipe et culture maison.',
};

export default function EquipePage() {
  return (
    <>
      <header className="pt-40 pb-16 bg-noir-salle">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          <span className="meta">Équipe · Culture · Valeurs</span>
          <h1 className="h-display text-ivoire mt-4 text-6xl md:text-8xl">
            Les visages d’<span className="text-or-akham">Akham</span>
          </h1>
          <span className="gold-line mt-6" />
        </div>
      </header>

      {/* Founder */}
      <section className="bg-[#0d0d0d] py-20">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div className="relative aspect-[4/5] overflow-hidden bg-anthracite group">
            <Image
              src={founder.portrait}
              alt={`Portrait ${founder.name}`}
              fill
              priority
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover grayscale group-hover:grayscale-0 transition-[filter] duration-700"
            />
            <div className="absolute inset-0 bg-or-akham/0 group-hover:bg-or-akham/15 transition-colors duration-700" />
          </div>
          <div className="lg:pt-12">
            <span className="meta">Fondateur</span>
            <h2 className="h-display text-ivoire text-5xl md:text-7xl mt-4">
              {founder.name}
            </h2>
            <p className="meta text-or-akham mt-3">{founder.role}</p>
            <span className="gold-line mt-6" />
            <p className="mt-8 text-ivoire-muted leading-relaxed">{founder.bio}</p>
            <blockquote
              className="h-display text-ivoire mt-12 border-l-2 border-or-akham pl-6"
              style={{ fontSize: 'clamp(28px, 3.5vw, 44px)', lineHeight: 1.15 }}
            >
              « Notre métier, c’est de tenir la lumière assez longtemps pour qu’une
              vérité se montre. »
            </blockquote>
          </div>
        </div>
      </section>

      {/* Équipe grid */}
      <section className="bg-noir-salle py-24">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          <span className="meta">L’équipe</span>
          <h2 className="h-display text-ivoire text-4xl md:text-6xl mt-3 mb-12">
            Celles & ceux qui font Akham
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-px bg-anthracite-2">
            {team.map((m) => (
              <div key={m.slug} className="group relative aspect-square overflow-hidden bg-noir-salle">
                <Image
                  src={m.portrait}
                  alt={`Portrait ${m.name}`}
                  fill
                  sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
                  className="object-cover grayscale group-hover:grayscale-0 transition-[filter] duration-700"
                />
                <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-noir-salle via-noir-salle/40 to-transparent translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                  <p className="meta text-or-akham">{m.role}</p>
                  <h3 className="font-display text-ivoire text-2xl mt-1">{m.name}</h3>
                  {m.speciality && (
                    <p className="text-xs text-ivoire-muted mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      {m.speciality}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Valeurs */}
      <section className="bg-anthracite texture-points py-24">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          <span className="meta">Culture & valeurs</span>
          <h2 className="h-display text-ivoire text-4xl md:text-6xl mt-3 mb-12">
            Quatre <span className="text-or-akham">A</span>.
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v) => (
              <div key={v.title} className="border-t-2 border-or-akham pt-6">
                <h3 className="h-display text-or-akham text-3xl">{v.title}</h3>
                <p className="text-sm text-ivoire mt-3 leading-relaxed">{v.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
