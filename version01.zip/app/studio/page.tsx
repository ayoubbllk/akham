import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowUpRight, Camera, Mic, Monitor, Lightbulb, Headphones, Cpu } from 'lucide-react';
import { StudioStatus } from '@/components/studio/StudioStatus';

export const metadata: Metadata = {
  title: 'Le studio',
  description: 'Espaces, équipements et disponibilité du studio Akham Films à Alger.',
};

const u = (id: string) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=1600&q=80`;

const SPACES = [
  { src: u('photo-1574267432553-4b4628081c31'), alt: 'Studio photo plateau' },
  { src: u('photo-1598550476439-6847785fcea6'), alt: 'Cabine podcast' },
  { src: u('photo-1574717024653-61fd2cf4d44d'), alt: 'Salle de montage' },
  { src: u('photo-1497032628192-86f99bcd76bc'), alt: 'Plateau cinéma' },
];

const EQUIP = [
  {
    icon: Camera,
    title: 'Caméras',
    items: ['Sony FX6 ×2', 'RED Komodo 6K', 'Sony A7S III', 'DJI Ronin 4D'],
  },
  {
    icon: Lightbulb,
    title: 'Lumière',
    items: ['Aputure 600x ×4', 'Nanlite Forza 720B', 'Quasar Q-LED', 'Mole-Richardson tungstène'],
  },
  {
    icon: Headphones,
    title: 'Son',
    items: ['Sound Devices MixPre-10', 'Sennheiser MKH-416 ×3', 'Lectrosonics HF', 'Cabine traitée Auralex'],
  },
  {
    icon: Mic,
    title: 'Studio podcast',
    items: ['4 Shure SM7B', 'RodeCaster Pro II', 'Captation 4 caméras', 'Streaming live'],
  },
  {
    icon: Monitor,
    title: 'Post-production',
    items: ['DaVinci Resolve Studio', 'Pro Tools Ultimate', 'Suite Adobe CC', 'Moniteur HDR EIZO'],
  },
  {
    icon: Cpu,
    title: 'Workflow',
    items: ['Stockage 200 To', 'Sauvegarde LTO-9', 'Transfert sécurisé Aspera', 'DIT sur plateau'],
  },
];

export default function StudioPage() {
  return (
    <>
      <header className="relative pt-40 pb-20 bg-noir-salle texture-grain overflow-hidden">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10 relative z-10">
          <span className="meta">Akham · Alger Centre</span>
          <h1 className="h-display text-ivoire mt-4 text-6xl md:text-8xl">
            Le <span className="text-or-akham">studio</span>
          </h1>
          <span className="gold-line mt-6" />
          <p className="mt-8 text-ivoire-muted max-w-2xl text-lg leading-relaxed">
            Un lieu pensé pour le travail. 600 m² entre studio photo, cabine podcast,
            salles de montage et plateau de prise de vues.
          </p>
        </div>
      </header>

      <section className="bg-noir-salle py-20">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          <span className="meta">Espaces</span>
          <h2 className="h-display text-ivoire text-4xl md:text-6xl mt-3 mb-12">
            Quatre espaces, une signature
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {SPACES.map((s) => (
              <div key={s.alt} className="relative aspect-cinema overflow-hidden bg-anthracite">
                <Image
                  src={s.src}
                  alt={s.alt}
                  fill
                  sizes="(min-width: 768px) 50vw, 100vw"
                  className="object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-noir-salle to-transparent">
                  <p className="meta text-ivoire">{s.alt}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-anthracite py-24">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          <span className="meta">Équipements</span>
          <h2 className="h-display text-ivoire text-4xl md:text-6xl mt-3 mb-12">
            Outils <span className="text-or-akham">cinéma</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-anthracite-2">
            {EQUIP.map(({ icon: Icon, title, items }) => (
              <div key={title} className="bg-anthracite p-8">
                <Icon size={32} strokeWidth={1.2} className="text-or-akham" />
                <h3 className="h-display text-ivoire text-2xl mt-5">{title}</h3>
                <ul className="mt-4 space-y-2 text-sm text-ivoire-muted font-mono">
                  {items.map((it) => (
                    <li key={it}>{it}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <StudioStatus />

      <section className="bg-noir-salle py-24 text-center">
        <div className="max-w-3xl mx-auto px-6 md:px-10">
          <h2 className="h-display text-ivoire text-4xl md:text-6xl">
            Réservez le studio
          </h2>
          <p className="mt-6 text-ivoire-muted">
            Tournages, photoshoot, podcast ou post-production : envoyez-nous votre
            besoin, nous revenons sous 24h ouvrées.
          </p>
          <Link href="/contact" data-cursor="cta" className="btn-or mt-10 inline-flex">
            Demander une réservation <ArrowUpRight size={16} />
          </Link>
        </div>
      </section>
    </>
  );
}
