import type { Metadata } from 'next';
import * as Icons from 'lucide-react';
import { services } from '@/data/services';
import { BudgetEstimator } from '@/components/services/BudgetEstimator';

export const metadata: Metadata = {
  title: 'Services',
  description:
    'Production cinéma, communication 360°, studio photo & podcast, post-production, consulting et production exécutive.',
};

const CAT_LABEL: Record<string, string> = {
  production: 'Production',
  technique: 'Technique',
  digital: 'Digital',
  conseil: 'Conseil',
};

export default function ServicesPage() {
  return (
    <>
      <header className="pt-40 pb-20 bg-noir-salle texture-pellicule relative overflow-hidden">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10 relative z-10">
          <span className="meta">8 métiers · 1 maison</span>
          <h1 className="h-display text-ivoire mt-4 text-6xl md:text-8xl">
            Nos <span className="text-or-akham">services</span>
          </h1>
          <span className="gold-line mt-6" />
          <p className="mt-8 text-ivoire-muted max-w-2xl text-lg leading-relaxed">
            Une chaîne complète, de l’idée à la diffusion. Akham travaille avec des
            réalisateurs, des marques, des institutions et des plateformes — toujours
            avec la même exigence cinématographique.
          </p>
        </div>
      </header>

      <section className="py-24 bg-noir-salle">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-anthracite-2">
          {services.map((s) => {
            const Icon =
              (Icons[s.icon as keyof typeof Icons] as Icons.LucideIcon) || Icons.Sparkles;
            return (
              <div
                key={s.id}
                className="group relative bg-noir-salle p-8 md:p-10 transition-colors hover:bg-anthracite"
              >
                <div className="flex items-start justify-between mb-6">
                  <Icon
                    size={36}
                    strokeWidth={1.2}
                    className="text-or-akham group-hover:scale-110 transition-transform"
                  />
                  <span className="meta text-ivoire-ghost">{CAT_LABEL[s.category]}</span>
                </div>
                <h2 className="h-display text-ivoire text-3xl md:text-4xl group-hover:text-or-akham transition-colors">
                  {s.title}
                </h2>
                <p className="mt-4 text-sm text-ivoire-muted leading-relaxed">
                  {s.description}
                </p>
                <ul className="mt-6 space-y-2">
                  {s.features.map((f) => (
                    <li
                      key={f}
                      className="text-xs text-ivoire flex items-start gap-2 before:content-['—'] before:text-or-akham before:mt-0.5"
                    >
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </section>

      <BudgetEstimator />
    </>
  );
}
