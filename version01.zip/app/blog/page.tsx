import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { posts } from '@/data/blog';

export const metadata: Metadata = {
  title: 'Journal de production',
  description: 'Coulisses, réflexions et regard sur le cinéma algérien.',
};

const CAT_LABEL: Record<string, string> = {
  coulisses: 'Coulisses',
  reflexion: 'Réflexion',
  interview: 'Interview',
  actualite: 'Actualité',
  fonds: 'Fonds & aides',
};

const CAT_COLOR: Record<string, string> = {
  coulisses: 'bg-fiction',
  reflexion: 'bg-services-cat',
  interview: 'bg-or-akham',
  actualite: 'bg-documentaire',
  fonds: 'bg-live-red',
};

export default function BlogPage() {
  const featured = posts.find((p) => p.featured) ?? posts[0];
  const rest = posts.filter((p) => p.slug !== featured.slug);
  return (
    <>
      <header className="pt-40 pb-16 bg-noir-salle">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          <span className="meta">Akham · Journal</span>
          <h1 className="h-display text-ivoire mt-4 text-6xl md:text-8xl">
            Journal de <span className="text-or-akham">production</span>
          </h1>
          <span className="gold-line mt-6" />
          <p className="mt-8 text-ivoire-muted max-w-2xl text-lg">
            Coulisses, réflexions et regard sur le cinéma algérien.
          </p>
        </div>
      </header>

      <section className="bg-noir-salle pb-32">
        <div className="max-w-[1600px] mx-auto px-6 md:px-10">
          {/* Featured */}
          <Link
            href={`/blog/${featured.slug}`}
            data-cursor="image"
            className="group block mb-16"
          >
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
              <div className="relative lg:col-span-3 aspect-cinema overflow-hidden bg-anthracite">
                <Image
                  src={featured.thumbnail}
                  alt={featured.title}
                  fill
                  priority
                  sizes="(min-width: 1024px) 60vw, 100vw"
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="lg:col-span-2 lg:pt-8">
                <span
                  className={`meta text-noir-salle px-2 py-1 inline-block ${CAT_COLOR[featured.category]}`}
                >
                  {CAT_LABEL[featured.category]}
                </span>
                <h2 className="h-display text-ivoire text-4xl md:text-6xl mt-5 group-hover:text-or-akham transition-colors">
                  {featured.title}
                </h2>
                <p className="mt-4 text-ivoire-muted leading-relaxed">{featured.excerpt}</p>
                <p className="meta text-ivoire-muted mt-6">
                  {new Date(featured.date).toLocaleDateString('fr-FR', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}{' '}
                  · {featured.readTime} min · {featured.author}
                </p>
              </div>
            </div>
          </Link>

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            {rest.map((p) => (
              <Link
                key={p.slug}
                href={`/blog/${p.slug}`}
                data-cursor="image"
                className="group block"
              >
                <div className="relative aspect-cinema overflow-hidden bg-anthracite">
                  <Image
                    src={p.thumbnail}
                    alt={p.title}
                    fill
                    sizes="(min-width: 768px) 50vw, 100vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
                <span
                  className={`meta text-noir-salle px-2 py-1 inline-block mt-5 ${CAT_COLOR[p.category]}`}
                >
                  {CAT_LABEL[p.category]}
                </span>
                <h3 className="h-display text-ivoire text-3xl md:text-4xl mt-4 group-hover:text-or-akham transition-colors">
                  {p.title}
                </h3>
                <p className="mt-3 text-ivoire-muted leading-relaxed">{p.excerpt}</p>
                <p className="meta text-ivoire-ghost mt-4">
                  {new Date(p.date).toLocaleDateString('fr-FR', {
                    day: '2-digit',
                    month: 'long',
                    year: 'numeric',
                  })}{' '}
                  · {p.readTime} min
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
