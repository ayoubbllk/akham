import type { Metadata } from 'next';
import Link from 'next/link';
import Image from 'next/image';
import { notFound } from 'next/navigation';
import { posts, getPost } from '@/data/blog';
import { ArrowUpRight } from 'lucide-react';

interface Props {
  params: { slug: string };
}

export async function generateStaticParams() {
  return posts.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = getPost(params.slug);
  if (!post) return { title: 'Article introuvable' };
  return {
    title: post.title,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      images: [post.thumbnail],
    },
  };
}

function renderBody(content: string) {
  return content.split('\n\n').map((block, i) => {
    if (block.startsWith('## ')) {
      return (
        <h2
          key={i}
          className="h-display text-ivoire text-3xl md:text-4xl mt-12 mb-4"
        >
          {block.replace(/^##\s+/, '')}
        </h2>
      );
    }
    if (block.startsWith('> ')) {
      return (
        <blockquote
          key={i}
          className="border-l-2 border-or-akham pl-5 my-8 text-or-akham font-display text-2xl md:text-3xl leading-snug"
        >
          {block.replace(/^>\s+/, '')}
        </blockquote>
      );
    }
    return (
      <p key={i} className="text-ivoire/95 mb-6" style={{ fontSize: 18, lineHeight: 1.9 }}>
        {block}
      </p>
    );
  });
}

export default function PostPage({ params }: Props) {
  const post = getPost(params.slug);
  if (!post) notFound();

  const headings = post.content
    .split('\n\n')
    .filter((b) => b.startsWith('## '))
    .map((b) => b.replace(/^##\s+/, ''));

  return (
    <article className="bg-noir-salle">
      <header className="pt-40 pb-16 max-w-3xl mx-auto px-6 md:px-10">
        <Link href="/blog" className="meta text-ivoire-muted hover:text-or-akham">
          ← Journal
        </Link>
        <h1 className="h-display text-ivoire text-5xl md:text-7xl mt-6 leading-tight">
          {post.title}
        </h1>
        <p className="meta text-ivoire-muted mt-6">
          {new Date(post.date).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
          })}{' '}
          · {post.readTime} min · {post.author}
        </p>
      </header>

      <div className="relative max-w-5xl mx-auto px-6 md:px-10">
        <div className="relative aspect-cinema overflow-hidden bg-anthracite">
          <Image
            src={post.thumbnail}
            alt={post.title}
            fill
            priority
            sizes="(min-width: 1024px) 1024px, 100vw"
            className="object-cover"
          />
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 md:px-10 mt-16 grid grid-cols-1 lg:grid-cols-[200px_1fr] gap-12">
        {headings.length > 0 && (
          <aside className="hidden lg:block">
            <div className="sticky top-32">
              <span className="meta">Sommaire</span>
              <ol className="mt-4 space-y-2 text-sm text-ivoire-muted">
                {headings.map((h, i) => (
                  <li key={i}>{h}</li>
                ))}
              </ol>
            </div>
          </aside>
        )}
        <div className="max-w-2xl">{renderBody(post.content)}</div>
      </div>

      <section className="max-w-3xl mx-auto px-6 md:px-10 mt-24 mb-32 border-t border-or-akham/20 pt-12 text-center">
        <span className="meta">Un projet en tête ?</span>
        <h3 className="h-display text-ivoire text-4xl md:text-5xl mt-3">
          Pitchez-nous votre histoire
        </h3>
        <Link href="/pitch" data-cursor="cta" className="btn-or mt-8 inline-flex">
          Pitcher votre projet <ArrowUpRight size={16} />
        </Link>
      </section>
    </article>
  );
}
