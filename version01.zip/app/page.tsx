import { HomeHero } from '@/components/home/HomeHero';
import { Manifesto } from '@/components/home/Manifesto';
import { FeaturedFilms } from '@/components/home/FeaturedFilms';
import { ServicesPreview } from '@/components/home/ServicesPreview';
import { Stats } from '@/components/home/Stats';
import { PartnersTicker } from '@/components/home/PartnersTicker';
import { ShowreelCTA } from '@/components/home/ShowreelCTA';

export default function HomePage() {
  return (
    <>
      <HomeHero />
      <Manifesto />
      <FeaturedFilms />
      <ServicesPreview />
      <Stats />
      <PartnersTicker />
      <ShowreelCTA />
    </>
  );
}
