import type { Film } from '@/lib/types';

const u = (id: string, w = 1600, h = 900) =>
  `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&h=${h}&q=80`;

export const films: Film[] = [
  {
    slug: 'el-guerrab',
    title: 'El Guerrab',
    titleFr: 'Le Passeur',
    year: 2023,
    category: 'documentaire',
    director: 'Youcef Mansour',
    duration: 52,
    synopsis:
      "Au cœur de la vieille Casbah, Si Mohand, dernier porteur d'eau, parcourt chaque jour les ruelles avec son outre en peau. Tandis que la ville moderne oublie ses gestes ancestraux, El Guerrab incarne une mémoire vivante, fragile, irremplaçable. Un portrait intime sur la transmission, le temps qui passe, et ceux qui refusent de s'éteindre.",
    synopsisShort: 'Portrait du dernier porteur d’eau de la Casbah d’Alger.',
    poster: u('photo-1485846234645-a62644f84728', 800, 1200),
    still: u('photo-1518457607834-6e8d80c183c5', 1920, 803),
    gallery: [
      { src: u('photo-1518457607834-6e8d80c183c5', 1600, 670), alt: 'Si Mohand dans la Casbah', makingOf: u('photo-1502134249126-9f3755a50d78', 1600, 670) },
      { src: u('photo-1492321936769-b49830bc1d1e', 1200, 1600), alt: 'Outre traditionnelle' },
      { src: u('photo-1469474968028-56623f02e42e', 1600, 900), alt: 'Toits de la Casbah' },
      { src: u('photo-1500382017468-9049fed747ef', 1600, 900), alt: 'Ruelles d’Alger', makingOf: u('photo-1485846234645-a62644f84728', 1600, 900) },
    ],
    status: 'sorti',
    awards: [
      'Prix du documentaire — Festival d’Alger 2023',
      'Mention spéciale — JCC Carthage 2023',
    ],
    crew: [
      { role: 'Réalisation', name: 'Youcef Mansour' },
      { role: 'Production', name: 'Akham Films' },
      { role: 'Image', name: 'Salim Belaïd' },
      { role: 'Son', name: 'Nadia Kheireddine' },
      { role: 'Montage', name: 'Reda Tahiri' },
      { role: 'Étalonnage', name: 'Studio Akham' },
    ],
    festivals: [
      { name: 'Festival International du Film d’Alger', year: 2023, award: 'Prix du documentaire' },
      { name: 'JCC Carthage', year: 2023, award: 'Mention spéciale' },
      { name: 'Vues d’Afrique — Montréal', year: 2024 },
      { name: 'FESPACO', year: 2024 },
    ],
    trailerUrl: 'https://player.vimeo.com/external/371433846.sd.mp4?s=236da2f3c0fd273d2c6d9a064f3ae35579b2bbdf',
  },
  {
    slug: 'tizgui',
    title: 'Tizgui',
    titleFr: 'La Forêt',
    year: 2024,
    category: 'fiction',
    director: 'Lina Boudiaf',
    duration: 95,
    synopsis:
      "Dans un village kabyle isolé par la neige, deux frères revenus de l'exil découvrent que la maison familiale n'est plus tout à fait celle qu'ils ont quittée. Tizgui interroge la mémoire, l'héritage et la solitude des hommes face à la nature.",
    synopsisShort: 'Long-métrage de fiction. Deux frères, un retour, une montagne.',
    poster: u('photo-1542204165-65bf26472b9b', 800, 1200),
    still: u('photo-1483728642387-6c3bdd6c93e5', 1920, 803),
    gallery: [
      { src: u('photo-1483728642387-6c3bdd6c93e5', 1600, 670), alt: 'Paysage enneigé' },
      { src: u('photo-1418065460487-3e41a6c84dc5', 1200, 1600), alt: 'Portrait acteur' },
      { src: u('photo-1465056836041-7f43ac27dcb5', 1600, 900), alt: 'Forêt kabyle' },
    ],
    status: 'post-production',
    crew: [
      { role: 'Réalisation', name: 'Lina Boudiaf' },
      { role: 'Production', name: 'Akham Films · Coproduction Arte France' },
      { role: 'Scénario', name: 'Lina Boudiaf, Karim Si Ali' },
      { role: 'Image', name: 'Salim Belaïd' },
    ],
  },
  {
    slug: 'casbah-90',
    title: 'Casbah 90',
    year: 2022,
    category: 'court-metrage',
    director: 'Youcef Mansour',
    duration: 18,
    synopsis:
      "Alger, été 1990. Un adolescent traverse la Casbah avec son walkman. Court-métrage en pellicule 16mm, hommage aux étés disparus.",
    synopsisShort: 'Court-métrage 16mm. Alger, l’été d’avant la nuit.',
    poster: u('photo-1502134249126-9f3755a50d78', 800, 1200),
    still: u('photo-1500382017468-9049fed747ef', 1920, 803),
    gallery: [
      { src: u('photo-1500382017468-9049fed747ef', 1600, 670), alt: 'Casbah 1990' },
      { src: u('photo-1502134249126-9f3755a50d78', 1600, 900), alt: 'Walkman' },
    ],
    status: 'sorti',
    awards: ['Sélection officielle — Clermont-Ferrand 2023'],
    crew: [
      { role: 'Réalisation', name: 'Youcef Mansour' },
      { role: 'Image', name: 'Salim Belaïd' },
    ],
  },
  {
    slug: 'al-bahr',
    title: 'Al Bahr',
    titleFr: 'La Mer',
    year: 2025,
    category: 'documentaire',
    director: 'Yasmine Cherif',
    duration: 78,
    synopsis:
      "Sur la côte ouest algérienne, des pêcheurs tentent de transmettre un métier qui s'éteint. Al Bahr est une ode salée à ceux qui savent encore lire la mer.",
    synopsisShort: 'Long-documentaire. Les derniers pêcheurs d’Aïn El Turck.',
    poster: u('photo-1505142468610-359e7d316be0', 800, 1200),
    still: u('photo-1507525428034-b723cf961d3e', 1920, 803),
    gallery: [
      { src: u('photo-1507525428034-b723cf961d3e', 1600, 670), alt: 'Mer Méditerranée' },
      { src: u('photo-1500375592092-40eb2168fd21', 1600, 900), alt: 'Vagues' },
    ],
    status: 'developpement',
    crew: [
      { role: 'Réalisation', name: 'Yasmine Cherif' },
      { role: 'Production', name: 'Akham Films' },
    ],
  },
  {
    slug: 'kif-kif',
    title: 'Kif-Kif',
    year: 2024,
    category: 'fiction',
    director: 'Karim Si Ali',
    duration: 110,
    synopsis:
      "Comédie sociale autour d'une famille algéroise dont les codes volent en éclats à l'arrivée d'un cousin parisien. Tendre, drôle, incisif.",
    synopsisShort: 'Comédie sociale algéroise. Sortie nationale prévue 2025.',
    poster: u('photo-1489599849927-2ee91cede3ba', 800, 1200),
    still: u('photo-1489599849927-2ee91cede3ba', 1920, 803),
    gallery: [
      { src: u('photo-1489599849927-2ee91cede3ba', 1600, 670), alt: 'Plateau Kif-Kif' },
    ],
    status: 'post-production',
    crew: [
      { role: 'Réalisation', name: 'Karim Si Ali' },
      { role: 'Production', name: 'Akham Films' },
    ],
  },
];

export const getFilm = (slug: string) => films.find((f) => f.slug === slug);
export const featuredFilms = () => films.filter((f) => f.status !== 'developpement').slice(0, 3);
