import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        'noir-salle': '#080808',
        'anthracite': '#111111',
        'anthracite-2': '#1A1A1A',
        'or-akham': '#D4A017',
        'or-hover': '#EAB92D',
        'or-brule': '#3D2B00',
        'ivoire': '#F2EDE4',
        'ivoire-muted': 'rgba(242,237,228,0.55)',
        'ivoire-ghost': 'rgba(242,237,228,0.25)',
        'fiction': '#D85A30',
        'documentaire': '#1D9E75',
        'services-cat': '#534AB7',
        'live-red': '#E24B4A',
      },
      fontFamily: {
        display: ['var(--font-bebas)', 'sans-serif'],
        body: ['var(--font-dmsans)', 'sans-serif'],
        mono: ['var(--font-jetbrains)', 'monospace'],
      },
      aspectRatio: {
        'cinema': '2.39 / 1',
        'affiche': '2 / 3',
      },
      letterSpacing: {
        'meta': '0.12em',
      },
      animation: {
        'grain': 'grain 8s steps(10) infinite',
        'ticker': 'ticker 40s linear infinite',
        'blink': 'blink 1.5s ease-in-out infinite',
        'scroll-down': 'scroll-down 2.2s ease-in-out infinite',
      },
      keyframes: {
        grain: {
          '0%, 100%': { transform: 'translate(0,0)' },
          '10%': { transform: 'translate(-5%,-10%)' },
          '20%': { transform: 'translate(-15%,5%)' },
          '30%': { transform: 'translate(7%,-25%)' },
          '40%': { transform: 'translate(-5%,25%)' },
          '50%': { transform: 'translate(-15%,10%)' },
          '60%': { transform: 'translate(15%,0%)' },
          '70%': { transform: 'translate(0%,15%)' },
          '80%': { transform: 'translate(3%,35%)' },
          '90%': { transform: 'translate(-10%,10%)' },
        },
        ticker: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        blink: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.3' },
        },
        'scroll-down': {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' },
        },
      },
    },
  },
  plugins: [],
};

export default config;
